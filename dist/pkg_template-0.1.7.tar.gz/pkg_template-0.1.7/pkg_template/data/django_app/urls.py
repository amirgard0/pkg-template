from .views import *

urlpatterns = [
    
]
