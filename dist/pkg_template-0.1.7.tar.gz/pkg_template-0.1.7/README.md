# pkg-template

its a simple cli program developed by amirgard0.

## what does pkg-template do

1. it create a pypi pkg template

- > pkg-template -c \<name>

2. it update pkg's version:

- > pkg-template -u \<version>
- you can add path to it
- - > pkg-template -p \<path> -u \<version>

3. it create a django template

- > pkg-template -d \<name>

4. it make django app and confing it in url and setting (i love it)

- > pkg-template -a \<name>

---
